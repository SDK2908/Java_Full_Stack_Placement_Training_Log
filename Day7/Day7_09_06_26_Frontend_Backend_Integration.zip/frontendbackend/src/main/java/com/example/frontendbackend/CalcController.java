package com.example.frontendbackend;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@CrossOrigin(origins = "*") // Fixes CORS issues
public class CalcController {
    private double round(double value) {
        // Keeps results neat down to 2 decimal places
        return Math.round(value * 100.0) / 100.0;
    }

    @GetMapping("/calc/add/{n1}/{n2}")
    //public String add(@PathVariable double n1, @PathVariable double n2) {
    //    return String.valueOf(round(n1 + n2));
    //}
    public Map<String,Object> add(@PathVariable int n1, @PathVariable int n2){
        return Map.of("operation", "addition", "result", n1+n2); //for the JSON Demo to return in key value pairs.
    }

    @GetMapping("/calc/sub/{n1}/{n2}")
    public String sub(@PathVariable double n1, @PathVariable double n2) {
        return String.valueOf(round(n1 - n2));
    }

    @GetMapping("/calc/mul/{n1}/{n2}")
    public String mul(@PathVariable double n1, @PathVariable double n2) {
        return String.valueOf(round(n1 * n2));
    }

    @GetMapping("/calc/div/{n1}/{n2}")
    public String div(@PathVariable double n1, @PathVariable double n2) {
        if (n2 == 0) {
            return "Error: Div by 0";
        }
        return String.valueOf(round(n1 / n2));
    }

    @GetMapping("/calc/power/{n1}/{n2}")
    public String power(@PathVariable double n1, @PathVariable double n2) {
        return String.valueOf(round(Math.pow(n1, n2)));
    }

    @GetMapping("/calc/sqrt/{n1}")
    public String sqrt(@PathVariable double n1) {
        if (n1 < 0) {
            return "Error: Invalid Input";
        }
        return String.valueOf(round(Math.sqrt(n1)));
    }

    @GetMapping("/calc/sin/{n1}")
    public String sin(@PathVariable double n1) {
      return String.valueOf(round(Math.sin(n1)));
    }

    @GetMapping("/calc/cos/{n1}")
    public String cos(@PathVariable double n1) {
        return String.valueOf(round(Math.cos(n1)));
    }

    @GetMapping("/calc/tan/{n1}")
    public String tan(@PathVariable double n1) {
        return String.valueOf(round(Math.tan(n1)));
    }

    @GetMapping("/calc/log/{n1}")
    public String log(@PathVariable double n1) {
        if (n1 <= 0) {
            return "Error: Invalid Input";
        }
        return String.valueOf(round(Math.log10(n1)));
    }

    @GetMapping("/calc/exp/{n1}")
    public String exponential(@PathVariable double n1) {
        return String.valueOf(round(Math.exp(n1)));
    }


    @GetMapping("/spiral")
        public String spiral() {
        int[][] arr = {{1, 2, 3, 4},
                {5, 6, 7, 8},
                {9, 10, 11, 12},
                {13, 14, 15, 16}};

        String result="";

        int top = 0;
        int left = 0;
        int bottom = arr.length-1;
        int right = arr[0].length-1;
        while(top<=bottom && left<=right){
            for (int i = left; i <= right; i++) {
                result += arr[top][i] + " ";
            }
            top++;

            for (int i = top; i <= bottom; i++) {
                result += arr[i][right] + " ";
            }
            right--;

            if (top <= bottom) {
                for (int i = right; i >= left; i--) {
                    result += arr[bottom][i] + " ";
                }
                bottom--;
            }

            if (left <= right) {
                for (int i = bottom; i >= top; i--) {
                    result += arr[i][left] + " ";
                }
                left++;
            }
        }

        return result;

    }

}