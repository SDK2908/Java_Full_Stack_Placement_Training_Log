package com.example.coffeeorder;

//Model Class
public class Coffee {
    private int id;
    private String name;
    private String type;


    public int getId() {
        return id;
    }

    //Setter for id
    public void setId(int id) {
        this.id = id;
    }

    //Getter for name
    public String getName() {
        return name;
    }

    //Setter for name
    public void setName(String name) {
        this.name = name;
    }

    //Getter for type
    public String getType() {
        return type;
    }

    //Setter for type
    public void setType(String type) {
        this.type = type;
    }
}