package com.example.coffeeorder;

import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class CoffeeService {

    private List<Coffee> orders = new ArrayList<>();
    private int nextId = 1;

    //Business logic: add coffee order
    public Coffee orderCoffee(Coffee coffee) {
        coffee.setId(nextId);
        nextId++;
        orders.add(coffee);
        return coffee;
    }

    //Business logic: list all orders
    public List<Coffee> getOrders() {
        return orders;
    }
}