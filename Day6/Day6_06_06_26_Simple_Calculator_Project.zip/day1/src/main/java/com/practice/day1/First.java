package com.practice.day1;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.Locale;

@RestController

public class First {

    @GetMapping("/myhtml")
    public String sayHello(){
        return "<h1>Samyuktha Dheepthi K</h1>" +
                "<p>This is a demo</p>" +
                "<script> function handleClick(){ alert('This is a demo.') } </script>" +
                "<button onclick='handleClick()'>Demo</button>" +
                "<p style=\"color:red;\">Can this be auto refreshed?</p>" +
                "<img src=\"data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBwgHBgkIBwgKCgkLDRYPDQwMDRsUFRAWIB0iIiAdHx8kKDQsJCYxJx8fLT0tMTU3Ojo6Iys/RD84QzQ5OjcBCgoKDQwNGg8PGjclHyU3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3Nzc3N//AABEIASgBigMBIgACEQEDEQH/xAAbAAACAwEBAQAAAAAAAAAAAAACAwABBAUGB//EAEUQAAEEAQIDBQQIAwUHBAMAAAEAAgMRBBIhBTFBBhMiUWEUcYGRFSMyQlKhwdEHYrFDcoLh8CQzU5KTovEWRLLSJWPC/8QAGQEBAQEBAQEAAAAAAAAAAAAAAQACAwQF/8QAJxEBAQEAAgEEAgEEAwAAAAAAAAERAhIhAzFRYRNBIgQUM4EyQnH/2gAMAwEAAhEDEQA/APW6VRam0qIXseAqlWlN0qi1IwrSqLU0hUWpGFFqoNTS1WGWrQuFgNXz9F1cKFgOr5rFDCb2C60DGtaL+S5c69Ho8Wlt/wCvJKmkpW9+gc/EsM8llc5Ho5cshzHEm09p1Ciub3rvNX37xsDzWurnPUaZpNLtissjnPKjSXequd4ayh05+q1ILy1kmk0Ai1zppC4+ibO8uPNIItduMx4+fLS6VUmUpS25FUqITKUISCqRtarDUxrVLBRDda2Gklh6UtMLG9L+K5124Rog1OPhWp7CGW4gegCDH1N6CkUurSSL3XL9vVPZz55aO17eaBjmuNUreyyQbUjFcxRXTw4ftb9LHUUyItdsq7oyCwKpRsThzKLWpumOh5VRtLczT9w+qaIjY8XL1TxE6tiN1nW+usjGMeNiWlKkjLTztaXwaXHcJUjaH2h81qVmxlJoEFKcxp3Ngpz3gLPI+10jhyoHsYluAHJW6ylkE9VvHG1H1W/NIdSJ4PmgrZakcrQloKEtAR+9UUsh0odKM2hspQSzdA8VsmOOyURambS6VUmUqpLL2Zaq0p+lCQvDr7FhOlCWp+lUWqGEUqpOLUOlOs4XpTBHQtWG2QFraPBRCLW+PHSoTW+66MWoAOcKJ5LPDFbgt5bpZZ5rnyrvw4+GWV2kevVYnkkrRKbJSitcWeRVUqopgbaKg1tp1nA33bLKwZMxedinzvdKdIBSDAR9oELfGZ7uXO2+IzEKtK0mFV7O/ot65dazEKqWn2aToCVPZnjmFdoOlZCFKWr2c+SsY58ldoulZK9ExjCeS0txt9wtUWO1F5xvj6VrJExwOwXQiiJbdBG2ACjS1RxbbBcuXN6OHpEsi07hHpcee61Ni8wmDHJ6Lneb0T03MONbrpEMMHfSuq2ABOZE3qEX1DPSjkMxRVFvuRDFHlsupLG1ovYLFNkxxgi79AicrfZdOM92dzWRgbtA9VRcwcyFxe0YizIsQzxtd3eZE5urodQF/mtmuhuuk41x5c5PZMt4adlgkdZWmaRruiyvPou3GPL6nLSnGkt5PmiduUDmldY89pbrS3WmlAVpzpDgSqo+aaQhLVpgBCGrTdNqaQFLCgChLSm7KiEggtKrSngXsVRaGqGEFirSm2OqFQx7UhVpTSFWlfPfZwohUQm0q0rWjCdKotTy1CWq0YU0UQVsY0FlhZ9KfjuppBRWuLXjN6qZcoaNIUjeGNJWKaQvcTa5ybXW8siiUIKGyiXXHLVDmh7wOdpPI+iGR17BHA3xX1UN2+GpmI0VptwPVXJikWa2W3HeSBtS0uZ3jT68wuN53XpnpyxwvZaKY3HDRuV03YwG6HugAnuJ6TnGOv8ANAWea3vZXJIc20zkLwxkLG+SHuwei1CMA7lGIheyezPXWdkJPRaI8Y+S1wsYwW+r8lC/yAWbyrrOMgGwgHdaI2MHVLa9NaW81i61MPaxtclZc0DklOftsVnlmI6okpvI+SZg3JWWXM6NWaV+oc1kkkPQLpx4Ry5epWt05dsXWkSNbZ3pZi8+dFLkkNfa+a6Ti431NcTtllSYvDoZIHtafbIASRexeF0jI7lt8l4f+IPGYzEOHYzz7QyZkjyKIob177I+S7vAuO4vGI6hJErGgyMPRb42bjnzl667BdfMJb90SpdY89L3AQuTSNktzVqOdJIQlqcQhK1rFJ0qaUxVQpOs4AtQkVzRlLcbSzSyqRkKqSyAoUdISFABVJlIdKg95SEhNpUQvnPu4WQh0phCqkgshVSbSEhQLpVyTKQ0kJrNUl0jpQhQByVOOyIhUQkFgbrXiRlzh0CSwAmiuhiAAgC/es8r4b9PjtdGGFpaE9sQARQjwg1SbQG681r17jO+MLLIPgtMz9IoLBLNVhMNuFyu0jks5lB5mlHzW7YpT3MFknfypdZxcOXMz7e1IDIIzz5JHtZrmAsj3lzib5rpODjy9WT2dL2sKe1X9kLmAnzWiO9k3hIzPVtb45CStDX+qwR/ErXCL81jlHfhy06yQkSg+q0horkgkYsSuljC5p9UpzfRa3AeZSXX0XSVxsZZAOlrK8enPZbn2OYCyzFblcuUfEe0EzMrjWZkOkYzXIas0aGwGy7X8OcoR8VlxY3h4miLqDuWmt/zXM7XcLbw3jc0THOk1/WgltfaN18OS7f8OMKJ82RnW7vIx3TRe1GifjsuXHe7v6mdH0BoPkrI80ItQ2vU+fyUSluTKQkLbnSiFVFO0qiAAlnCaQuCa6kspZLKGkwhUVpgohVSYQqpQLKEhMIVUpF0qpHSqkp7ylC1MpTSvma+5hWlVpTaVUnRhWlCWp1IaVowqlRCaQqpOjCi1CQmkKiEgohVSZSohKUxovfkujh+IgN5LAxllbopRGNLefoscnT03XY8Xpb05o3uAbuVz48gMbZWTJ4gXcuS5TjbXW8pDcucB3NYJJwUmWVz0krtx4Y8/P1d9lyPs2EouJCIhVS6SONpRQ0m0qIWmMA3mnMJOzRfvS9KYxhJVVD4ySatb4GnZZIWgeZW6EH4Ljyer04f5AoH0rc6gkSP8lzjvb4BIQOQCzySADYK5Hu6fmkPJXWRw5cgvkWSdxpPdazyXXJdI48rr5r/ABHDHcUicW6njHHIVp8fM+fULb/DktGLmRsDmnWxxaW8rHK+vRc/+Ixb9MMt3/tm1pAu9Xz/ANe9aP4bub32Y1pOl0THAEjpz5e9c5/kdef+J7sIlTQj0r0x4aBREWqqSyElASUwhCWpZpVKqTC1VSWcKIVEJhCohOs4UQqITCFVJ0YUqTKQkJGFkWVNKMhVSlj3tKqR0qpfL197AKqR0qpIwNISjVUoAIQkJlKkjCiFVJpCGk6MLpVSYQhpOs4DkjYa3VUqIUvZcsrnfBIIJTC1UQmC+SyFWlMIVUnWcKLVVJpCohOjCi1VSbSqkyjqWGprGEnYK2N3WyFgCzeTfDhq4IvNamiuikYFqPdS4269XHjkKkJJ2SnN8yre43slOK1GaB9DdZ3kdAE5wS3N9FuOPKEOPkkyk1utLh5pEjRS252PmP8AEJzvpV1NbXctaXWN+RqkXYCYu4mWucHOdi+JwffLu6HwCV/EN0Y4rJr1udoAAB2aNI3VdgpG/SWN3bHNYWujNuB1O0Wf/jy6WuU/5uvL/E+kMCNU0IqXpeLAKqTKVFLNhRCqkwhVS0zhaohHSqkgshUQmEKiFM4UQqpMIQ1aRhZCEhMpUQoYUQqpMKGioY96pSMhSl8x9/C6VEJlKqVowFISEykJCdGApVSYQhITqwsqUmUh0q0YXSophFoaTrOFkKiEwhVSRhVKiEylRCdHUulRamUqITowohUm0qpOs4WoG7o9KdFFZReWGcdVFFe5WuONExgaPVHp965Xlr0ceOI6mhIkK0abbukPaiN1ncgTSAqsAHz5BalYvEojZA5G4+iU5ajnyLes8gCe5JeF1jjXzHt+94zsoNhd9oAv0bV3Q2ut/wDz5LP2Pkl9t4a6WNzfrg1p0gDQWvAI897381o7etkdl5ZD4ywTjw67cHdz+HpsPht5rmdlC9k0L3G3My4DqFmml4FE1Q5/1XLf5O1n8H1lqKlGhHS9OvFYWqKYQqITrNhdKqTKVUlmwohUQmEKiE6MKIVEJlIa3VrOFkKqR0qKdFhZCGkwhVSWcKIVJlKqUse9pSkzSqpfL197Cy1UWptKiFaCqQkJ1Ki1WrCqVUm6VNITqwghVSc4IKTqLIVUmEISFaMLIVEJhCGlasBSohHSEplGApUUZVEJ1nqWVKR0hpOjqoA2nssAJcbC52ye1m6za1w4jZqJC0tFBKYAOqe0WFztdpCpDQ2KzPJK2PaElzQqVWMtISFoIS3NC1KzYzuGyW5aXMQEAdFucmLwZi20qRtDe1rNJEi1OTF4Y+N9vH554xlNsnEdkHQ2NwsuEYBsc+RPTlS5nAW5w76THn7uGFzJp4nPNOaHA2B1Oy9T2yYx0OSWSm35b9bTy2a4Vy6e/e/Ref7OwY7+GcX1vkEgxiWkfZB8W19Hcq9LWP8As1f+L7EGoqQ47hJBHIDYexp/JMXpleOwNKqRlUUs4ClRCOlVJ0YXSohMIQkJ1mwshCQmEISEs2FkIaTCFRCRhRVJhaqITrOFEIaTCpStGPoFKUjKpfKfdBpVEI1VK1YWQpSMtVaVLCyFSZSohSwoi0OlNLVWlOjCS0oSE8tQlqdGE0qpO0oS1WrCSFRCdpQlqdWEkKqTS1CWp0YUQqTCFRCtGJEQCtA0nqspCgcR1UZ4bmtA3Ra65FYmyPJ5laGM2tyxXSXTAXO6o+7HVyWL5BQgjmVko5oHJKdXkmHcckpwKYgOrySXEdAmu0jmlPcwHYFblZsLLv5Uh/NNe+0o7uHvW458nyztRJw6TDy9b8h0pzJNTWatAOp48e2nqNPxXJ7MNw438Rhz5MgB0Q8UV931Fmjz3AB6f17HGWcOn4WJWslc98xdMW6iDbiaJGwdZ2sctudLl9jG4H0hkOkxZHsEQPesYXdxvuT5t9+2wPRX7H6fTOzkvtHAeHS2CXY7L+S6S4nYp0buzuO2IgsifLE2jezZHAb9dqXd2XWXw894hUpEpS1rN4gIVUjKFOs3iEhCQjIQlOs9QFDSMhUU6OoCEJCMhVSdZ6gIQkIyENJ0YAhDSZSGk6sfQVVIqUXydfW0FKqRqK06BSkSFWnVUqpEorSGkJCMqlagUqIRqiFacLIVFqZSoq1YWWoS1MIVJ1YWWIdATUJVowotQlqaUJCdGFFqEtTiEKey6gYKK2RjUPRZtVckcUrtW5KKY1d2AN9vcq0trzV8wENLGtYp1VQCS9pTygcPRWtYyPYUl7VtdG4pbofNanNm8NYXNSZCGNLzyaLXQdGPNcrjzxj8H4hMDRjxpHX7mlbnPWLwfLuJS8G/9NwgNmkkc2Ky0P0auZs8tfPfy257rm9knYEHEsg50DnkwjS2IF2nYEu+A3PnyXd4/icEbwd0WJHcje7DqY+nNBAOh3LXR3JXF7JP4YOJy95hunikgaHRlpLmOAaPCfMm6PRbc8e67Cz48uLxCLDdqhizX6DVWHBrvM9XFemHNeU7JvxIuO8Ygwj9VIyCcDTpN0WmxZrkP2XqgVuVi8RKKAqJ7M9UKpWqKdZ6hIVFEqpa7C8QEISEwgVuUJ9E6zeKu72uwB6oXs0o9ztufRG3FmkGoAAebjSO2LpvtGUqiFpdA1uxfZ/lCX3e/Lb1Ke8H4aQUK1GNg+0VVQ+n/N/knvF+G/L29qWqUXy9e5CVVqFUnVi7VWoqVpWqUVEq0pzUUVWrShVWoVStKKlFFaVKlapWnFISiVWrssDSEhGaU2V2XUshVpTaU0hHddSC1DRTyAluA6JnNdVCZ42tWJXHmQh0k9Ffd2FdosGH/wAyMOHms5aRySy6USsLXNbGL1NLbJ8qN7fJGxrG20JSe+Vd8s0yCe1q4HbAxDs7mslJbHK0ROLXUac4NNHpsV3DIF84/iL2t4dJjTcGjdrlEtTUa06SCOYo7p422nlknlxu0ud2bOIMbEZJJIZA6bunOaIwB90WRvtz67rzvZ3LxOFcVOXlwTSwCAs7ssJ1HwgXuLHM17lxdbWmxMB4aIDvzVSGNooZRkBbRvUKXrnh4+Xmvd9jeI4UvatrsFz9ORjytka8EGw4OaLJN0LHRfSGm18G4NxH6K4lDmwua90JNNN0bFeXqvsnZ3jUHHcF2VjMkYwSFlSNomv/ACrTI7AVoQiAV2PVCVWyulWlPZnqoGtwofFuqKop0dRjuuZLz5ilDJE022IHb7xtKQlOrB98WusU3+6oZHHxHf3lKPNUSnwPK3SOPVAXFQqk6xZQuJPUqrRCuppTw/iKezPR7q1LQalLXyez14K1VobVWrscFampBaolXY4O1VoLVWrscHaq0GpVqR3PUy1VoLVEp7HqO1LQWqtXc4MlVaG1Vq7HBWqtVdqwFdkolXuir1U+KO6ULU3UJAQl9I7rFlvmqoBAXlAXFXZqcaaZAEBlPRLJQlWt9YJzyUOklQIwnUDuiqLaTS5LeUdlIRI6uQXyD+JHCmY3G+/xfrZs1rsiWNwFR1Q2PkaPyK+vyL4z/EOeXK7TZfdtJhx9GMHVY1AaiOfO3dF39G7yc/WmcXlB3zgQ2IEk7eHlztA184c3XFTbo+D18+i7vZvg/EOKS5HsuMZGxNp5FdaI6+hXZm7G8Zdjz1iSF7gXAks51sOa9Pabjy9bmvFB2QCQRyPPSN19s7JxYcXZ/B9gaWxPj10TZ1Hd1n32vi8AlmdKGt5NDgQB1r9wvqH8MsozcCOM9wL4H6h/ddZ/JwcEc/Y8Pd7JqNUwJlBc+zr1AqKMhVS1OTPUshCQmkICtdh1LcEJCYUKew6lkISmEi0JpPYdSyqKI80JV2HVRr1Q2PVWShtPZdXtLUtJ1qa18T8j09TrU1JBeprV+RdTiVRck61NafyHqbqVWlalNSvyHqYSqtL1qakd4eplqWl6lWtPddTLUtKL1XeDzV3PU61Nkgyt/EPmhMzBzcPmnuetarAU1hZPaGf8QfNCcqIf2jfmrsujYZEOsrGcyEf2jUJzoeWu/cE6ejYXqrWP26PpZ+CA58fkUy09W61Sw/SMXXb3oHcUhHn8Frz8HHQtS1yzxaLoD8wqPFWdGf8AcE+fhZHT2KIGlxzxUfhb/wAyo8V2+yPdurOSyO1qFJbiuSOKE/2Z/qhPEn/diJ+CuvI+HRnkbFG+V5AYxpc4nyG5Xw/KnnzIWSSxyMOXPLl34TrHQ1zHLnyIX0XtlxSaPs3mBg0yTNMTRpPUEn/tDl8wzJnStfJpa9uNjtjtsGmuQAfvuRR3Xp9DjZ7vP6/KXw97/CeJx4Vm5BaGmScNoeg/zXuXCjuvJ9hYpsXsriiNj294XvIB/mI/Rdd7slx3Eh/xLPOW8q36ck4x8dyMePF7Rz4eTE90Ykmi0sq+ZLefwXoP4f5LsLtA5r5T3GUTA1r26SSRrY6ugNPHxC5vbmF2H2lmmMZ8b4p23vzAB/NqTK7I+mYZMOSUyEhzDkR6Ps+Njf5SQCPj5L0e/F5fbk+1hzRzcFDKwCy4V71ysef2vGhyIADHKwPbv0IROiefvUFwx6fFdA5MX/Eb80By4R/aBc/2d34h8kTYntO5aR/dWsDWcyLo4n3BQ5LTyJ+Sy6T5j4KiD5rUZaTO0dUt+S1vX5LOWj/RQFjfIJWQ45jbqigdmD8JCXoaOQCrSOqWRHLJ5N/NAcp//D/NVpb5BCY2atVbp0J7W48wAq9qPp8lKHkFSdgdw8bP4QhPG3dGtXne+23LvmhMzvxFeCf0nF6fyz4ejPHJOgb8kJ43L5N+S893x6uKozE9Stf2vH4H5Y9B9MzdNPwCn0vknkR8l57vT5qd87zWp/Tcfhfljv8A0xk3zb8lR4vlfib+S4HfO/EqMzupT/bcfhn80d76WyT/AGo/JX9I5LueQB/iXnu9Pmp3jvxJ/t+K/M9Ac6UDfKb+aA5sh/8AdfIFcLvXDqr793oUz+ni/PHZOafvZLj8Et+YOkrlyu//AJW/JWJ2DnFGfmn8Ei/O6Xtresr/AJKvbIvvSSH3ALCMjG64/wAnI2TYP3oXD4q/Hn6X5PttGbAPvyn5Ke2YnV01rL33Dusb0Qm4Z+A/EFZ6T4rXf7jUMvD85fmmDMwaol/zKxd5ws87HwKu+GH7/wDVHWfFPa/MbfaMD8Z+ZVifh5+/fvK55+jb+2fzVkcNP9pSuk+z3vzHSD8E7gj5og7D6aPiVyw3h1f7xTTw/rIVdJ9jvfp1teL00fkiEuONgWfkuQGcPP8AaD4kq+6wOj2/NHSfZ736dcSQdCz8kQmh/Ez8lyO6wvxt+avusP8AG35q6T7Pe/TrieL8TPmFTsiFotz218FzGxYfRzPmuH27ZAOy+RpGoa2fY3rxc9kz09+RfUyaT284wxmfw3Gikj0xPEsh3Ok34eX90/NeIzcuKVs7ixnfzS+NkbXBukDmL8/Xf3LlDS0GpPgWFCS3Ww670my3QaK9XHhOMx4ufqXldfa+Fcf4Bh8KxMU8WxA6GFrHDX1rf8009qez+qvpbFPucvkjePiOERNhbpAqy3f+iju0BewNMDdiPu86+CxfQ47utz+osns9H/EXP4ZxHJw5eHZUeQe7dHLovajbT+ZXCfxBsvC8eOOcNkhp7oHQOGp7SaJde9gn+iwZ/FRm4/dGLR1toK55Y00C92ztvByC6zjJMcuXO26+p9heOYv0O7GzMiKJ+PIdGtwaCx1uFX5EkV0Xqo8vHlY2SOVjmOFhzTYK+Bxsha+N0jDKG/dcznvyX1/s29s3AcJ7oxETFs3blZpcuXpzddvT9S3w7/fRnk4KGRnmFzzo/E35oXOYPvBZ6OnZ0DI38QQGRvmFzy9v4ggLm/iHzT1GugZG+YQ62+YXPL2+YQl4/EnqOzod43zQ943zXPMgH3lRkH4h809RrcZG+aoyt81g1jzQl/qnBreZW+aHvB5rDrPmq1Hz/NWLTGywOkkY2eIuiNSN1i2+/wAuawS8b4XHMyE5sZc+qLTY35brwedlQmTHyYXAv27zXZkB9SeY9eax4sTiLDGEvH1Qsbu57+Spycq+r7EW1wcDyINgoVzOyjw7hbofZ3QPhkOpheHDffw+nvXX0jrWy3Bpapc3jHFX4QD4WsdEXhmsU7fzq1xn9sHY0xZNFHPGz7UjCNydwRRO1WFWyDXqlCvJjts32oNlwHiI0Ka63A/qvS8NllysCLInibEZBYDX6hXvVLKtNUR6VNK0NApSI6Q9rCRqdekedLPxbIGFgl91I86WbdVLTInNlibIw21wsFXpXO7O5Bkx347iSYgC2/wn/NdQilC0ulCEZUo3ySNBSqkStS0FKUjVhtc1AulEVBXXopA381KRgKODWtJcQABZvolBCsc1A+Lu+81t0edq9cYbeptedqSxfmiAKppa7k4HekxtXpsX5KQmArj9sc1uLwf2ceKXJcA0eTWmyf6D4ruDSwAvcGi6txoL5vx7icvEuKTTxN+pZTY9RI8A6/HcouGawOL28w3y5Imxului1pbu/bl/rb5oMfIlkc+27NF7E/AWuhGYJIosfGxJ8jNfRc9zy510RTWtrw78yjGtYjjSD7UmmrJ8PIDr86RNwJ3u0iRmq9NEfercfD/Vru4vY/jc7GkwxYzfKabxfJt/1QZ/ZLPwv95m4znlt6W94NvfXonBrjycPlZHrGTE7l8jyPx5enUBZWiUa2Ob4gaG12Bz/wBei6PEeFcQ4dKWZeM59AFz4X6gBsff+S50pa8tlxXuY6/E0ONEXy9PUqxalzbEb7Wab18l73snxAZfCmY7tpsYaHDzb0P6fBeAyJZGSNLWN0Ftg78/K1s4LxKbh2azLLLY06ZWtFWw/H/VKmC6+kklLc4+ayDjOI8gNZKbFg0N/wA0eNlx5bpBGx7THV6gFvGO1+TS8+aEuUP2iPJCSNvEPmjIdq9RVFyCeVsEZkksNBrYWkMzsZ8b5O8LWM+0XNIpWLtWguULrSMfJhyma8eQPHuIPyKaQVLvV6vVTUfMoDtuUDZYi4tEjC4cxe6sXanaz5qaj5oNTOj2/ND3sY++35pw96+alz+RaCwjdL71hiAY0tI3LtV38EPe1dnY9Adkkxs1EgbVt4qr8l5OMdq9T2S7QwcH75uTDJK2are13Ii/PfrS7XEe0mPxLAniEejHcBb2PIexfPYHG3Vs47c0Yc9ttYaaf6rXaxl0eI8SkyPDbWxh1hrGjfat6Atc/Xr2LtwlSuAAANoNVnc2EYmkyvYCPG1rhV9KtdjhvaCPCgET8b2h2ppEz3m2AfdaDyXnO8G4cQAPIJjHsLhyPWiE5ge7ye0/tgkfDjuj1tAAEgFUbVs4/mdw0Rzh82mtDWgAADzPNeSE8ZAMcgLPUbhNY5pNtIAvmVTnVkenHFOKzSslLmMe002y0Aeqmbk8Qyo2sy5WlzT4SC2t68l5nUHD/eNNKd8Y2ktdfkn8unq62PlcRwMnVDkDxNrYNN+/bzXYw+02RFFrzGBwutRbX9F5ODiDRWtni87RTZAmIc8g0KFJvOT2Zzy6XEOP5uXI0tyJIQNg2I6b9dvgscfFOJMcCMqcgHYayRtusRk0C27X580PtMgBpy57Tj1Una2U4TWCBgnoAyEn515rk/T/ABUOJGY9oJJNNbvfwXKM7jz3+CgJO4+S12ox6XhfaTiIl7qZzJwGk6izf40to7RZUchL4mEGrJvSF5Fkr4iSy2kjomOzJnw6ZXlwBsWtzl4GPVf+pZtNEQD+Y3Z/RU7tJmzMuGHHa07agSaPxK8c6XX5Un4bmh5bIA4EXX6pnNY9UzjvEAwtkEQJOzq/ZLdxWZ5+t0EltF1/5rzPt7mvtgBr5Kjkk7kNHo1tBPcY9d9KzPibjuji0sNijuUjM47HiBkUlahZ2Fn+q8nJJcjX0AQNq80t77JLqv1RfUpnGPW8O7RsmlDL7t55Fzea0QFkU/tDXkusncWN14YkhvefdvotcefpiBLzq6hqZz+RZHrOL8SmHD3YzX6tQJIAAIb13XmJpSManRsYXv1E6dx5D3JD8oZBF9B1N7K43atWQ8imdPM9EXlrUkjZiYhkf7PAdIaO8lkdyYP1PQBep4Nn4/B2n2KRjdQOova5xcfM7bleSwzLHCS6ShI7U5vmfP5LZAe/lMUfMCyU8eUZ5SvVT8f4nJI1+NlVG0AlpaAXHqOWyTk8b74uORLcgFAuadvTYLmY5HdNDpJBdEaQTbfNR7iWnQAXEEtJHP0966bjPu6LuKe2zvkc/wAekeIA+79FzOJcPxc90suNNGzKB1HT4Qf7379FhlzXOb3biWne6FELDG9jZC5su/oN1zvqRrrjNA8ZOrGyW6ZQeQ6lHDM9jhIzuxtocGt29zglcSbbmTR2HeYFbjko497GMppAJ2e3lv5rOtO5wjLbH9RM4As3abvbyXRlzm4bu/L3sbYIOk2PgvHDI0HU0guHMBKkzpX/AGwK5jZa71jrx16d3aCHK1Gd0gffhLmkgj4ck1mRHLIDFLjtrkeQ/NeSdJYaWkqxO5m4JtHenI9XlcXc2bucjKic08zqLgEbZpJXP7vTI0D7h/ruvHSSudu82ShbKYx4DpPUhU58l14vYjLfjPa6IOjkIPvPJVPxt+OGGbv5Xk3QcGtr16ryMc7rDtbrbuDfJas3O9qla/QG0AK1E7pvOjrHpMfjznyP7t7K0EaZpDuT5X1tJy8twGmRjImuNBwPiPJeY7warrcG0cmVLN/vXF58iic6fFj0tSCMPi8WvbxuqjfNZvbXdTv18Sw8K4p7JIe9eTHVFjuR2XYHHuAgAHHfY/8A1q/JWpw42PJeHanhKDy511y5Ls/QjAHOknyKbYs4cgAI5kpTuB0fFlStJ2F4cov8kTi1rA11A6aNn5KOc9uy3jgwNhubZB3/ANll/ZUeEscBJ7fFRqj3Elf0R1Gue5wFON0BsEBfYoAcq9y6buFNuvb4Q6uscg//AJSRwlt7cSxdvNr/AP6rU4i1zybH2haLcHeuVraOFxWB9KYNXtu/f/tW2PstnTN+rniLPdIB8y1PWi1y4arwphke0USQPVb39np8Y/X5/D2Drcpv+ihwOHtYXS8SdIBz9ngLgPiVi8KpWGOU60w94QDp2PKkE7cYOAxHzuA+13rQD6HZW1k0rSI9AjZs+RxprfefP0Wbx8tWo9r21qaQVIJS1xLALT2Bwse241efeEV+St0evb2jE5mj3m4/JXXl8M9oV37ifEbaed7oqDt2SNPp1S3YT/EG5GMRexEo3RxYDwbfJEfQSt3/ADV0sOh10i1At2NeqYcWWT7UbGkHYslZ+6F2BOD4Wk+R7xv7pkotgWEgnxClYdZ3IRnh8oIAa/3ij+qs4EsY8MUr75uA5FXWjSjp3+zXoqAPeGia9y0s4e9zdTYZ9PnIP0RuE+OPqseZz+WvQbWbc9moxEAbuJb8EV7fa58tkbpMmU6Z4JSPMxHZMjxJ5XBpgeWkfdHNM39gmKMOGpz9h5DmhkbGeTnX5ldOTg2axgDMWRzOdHokHguaTfs0gHkE9amJz21oDiQP6JYa1pJskdAu1h8CdPPpy45oIvxhhdXwUPB4u7IbhcRdLW1lobfyta6hxY7c/wAH2ugA6p0ryzFLHAsNgm7s/wCtl1H8NdG5r4+G5OvfYbhvuNBaMfhOXnNkkOJITCwvcH7UNhuTsmRXXBghfkxyvDS3S3UD0Ppa6cEseJw4t1kZMgqr2K2YOCyLScjhz3REXoDTz/RK4tw8jLxjiQSujH2rYSG7j08rWuuM7vuq6YHOlaNgLLXeSIOGgt74c7rSUyXGmkkFwta3y7u6/L9UEGA5k7pvZ2h2/ic3n8ldVbn6CyWFzzFmvvbwSt515FZX4MpkYIyHRnfvByXUdG4Ej2WF582xfukZLy5sbcfh7otP+81x3q91H3o6Nd3Ckge2R0b3M1A7jV8UqZ7Yy+OJ2qLVYdXNdiGDHn4jke0NdEHNOgOFUdqoqZGC1jgC0O0OsuArxfFHUdvLgPkIdyNnz5rTi8Nzs6Nxx4HuaPvO8I9wJTnMjlnJLX95I4myRzWv6Rybp2ZKK2AqqUfdzX4kmPUczXtkq9LmkUfLcKmdxREmvvQeXQLblSyZTGRzZJdXI9P9blZH8OkZC18U0MjidJAdTh81YNwIiaWueH7dAlNgkc3XocGXV+a2xRiGFjZGtJIJdR5pU+S9pDG7NbsAFy7XcjTNp28WsflspsCBaMv75pDnH0FK4sSVzqYC49LFLe/IZe88RJ28k4t1AO8Wk9Qmjh75HOtrrAskEAUizsafHDQ8aAao2Ddixy9E7L7C+CHxbDe7WcijX1m3om6Hg2S0fFaWywgAayrcT1j+02S7GmiOPikSl9kB22o+9I4nxabjAixzhstri+odRJ2r12XKbhZDn6RMQdWmnAVd9V0+JcRGC52BwSQlgoPyOrz+/r8BsLOZy8472eNa+EzcS4bA+OPBYGPk1l00mmjQH6eSaOLxxYcONk5GIzutH2C97jprptzpebE2fqP+1P1DmbRDK4i11e1PonYkrpOUY8vQydp8DvWysgkldoLBTtIN73ufTzWQ9qJdTvZsSBhe4kl7i7euf5LlHN4hZBnv32iOZnnnIwn1CuzP/p7OPZz9BdK1sbTpLIgGbXVWrfnslae9gdI50TmanzOPiP3q9FlZnZhY01FR5ClPa8ouHhgI/uD9kdvs59Og3ieP3rj9GweKQPIAFUBVcuqRPlY7o4izEYySMCy07P33sVvaxnKydW8MF1/wm/sgGXM5pJx8ctFg3G39laq3O4hjNzmZEeFCWNaWyRFoOq3E8q50tbOI8PkzDO7h7HQNjDY4jQaHfecRW5vb3BciCeaWVscGDA6V3INaATsmy50DKZjYkT5G/amLbBPoDtXvtXjV5x1YeJcKAdq4TE46ydw3lfLkljP4X7EI3cKYZdFd4A3nXPkuT9JZoALY4/foZ+yqbiuS0Fz4YwLAA7th/T0To/07U2ZwXwVwhoIeCdm8vLkhfl8DMzHfQ7Q2jqAYzfyXEZxSWV7WDGi1EHnC3fa/JM9vmB8WDF/0mK37W/TrCfgj5df0U0Rlgpuht3ZQsPAu8kc/htixpAaNhQ9fNct2cWkhuBDprYCJqtnEJCw1gRXdECIc6/8ACt+1v06sH0Fpd3mDR1k/C9hz8krXwb2TT7G8Td3WqvvVz+15rnjiB1NHsEfXmwBUeI02/o8NbX4P81b9rfp0ZXcGdHbMWRrtQs77i9/veSqSTg2xjilaGus7u5Uf5lz3cQAHjwGb+QO6AZsTgS/AbV0dj1HvV/sb9OwX8J1x/V5TRvqAed9uniR6+DNlB/2/RoOwkN3Y/m96430hC5waMQWTTftc/mmyZP3/AGB1k1975c0rx8Op3vB++c0zcRa0gaRrN3vfX3Isd/C3OlvM4kGB31YDzyoc/ja40mXEx1S4NH/F+6FvEMUB2nG8Q3IJdsPPmrV4+Hfhl4W4OL+KcUb4zpp3Torh9gew95xrirXAuGwBFWa6eVLgx5uM5jnsxdTGnc6iav4ojn4rCWvxy3e+tq1PScHZPlTwQ8P4i/LmcLlhyY6a1v3nagNq/wAuqnbDjsLG/Q/C3H2aN+rIkBozO8lzsLjOTwzFm4djYDonT+F7wD3h25Xew5/M/Di+1YJBaI5HCuj+aPJ7ZHoO+ws/HfPnZsrZXh3dY8eprY+ekWBuUybH4GYHHHzMnXVj6x6897ZhkfZkBbyBf/krbk4ZoFztB2vUKB+Sdo2O7JjcI0uMHEMnvByHeO/ZVPjcLr6viWRq1C/rHcrF9PJcYZ+LX2nH/EL/AKKjlYWrV3jvWiP2VtXj4dt+Lwyh3fFsrYgO+tP2b36IZMbAFGPjeXRcNVyjYef2Vxjk4IsiVwroVTsvBIp0jhfpadq2OxNh4ZDTFxrIeb3t7TQ/5fcs8mJAdJbxeQi9yXNO3y9y5/tWDYqZwHL7IShJilvdjJdu2vsouj+LrexRDSW8VsE0SdO2x9EL8OAOb/8AlNQBp3hZt+S57GERuex7XsPJ1n8wlta/xWW79dYWds/R/jXV9igOgt4iCCaJLWbbHdUcCEvaG8QjIJp1xs222XLDPCfADY6vBv8ANANbQ8COvRW34OcXXk4dCXNDc6FzdVO+rbsK96qXhUZcz/bsUguo6oRsK581yC572u8DgK5hp81cbgGG7B07+E+atvwsjr/RgZ3Yjz8MgOoVCBV/4lH8NcKrOw3Bzqd9Xy/7lzYI3yxuew0w7FztgPmqaxjQ4e1Q7iqs+fuV/ofxjqO4Y8AVmYTtw0+Eih81UvCnuaA+fBeLAPPYfNcprGNse0w0RXM/sjhg3doyISC0igT+ypPoXq6M3CJGw6BJgOaSAQA4czV3azngAs+DD/67v2WdmJLf+8jIIIO53/JX7LONtce38x/ZM2fpbw+RMzJRCWPDT3rTTiCCN9zz3RxMaI2FtjXMBv8ABUoszy6/s8AB83K6/RUWisbluB+itRWAG3eY4/Fd/NRgHdn++/8AoVFFYkiYBBi7ev5hBGdq/k/VUorBvk3SO+cPX5bLFIA3HsczZ/MqKI/ao8XKfG6XuqaHxGImrJHX03/oixI2mL4+9RRXKeDxp8bQYSdro7hKlhEgDTY06Tt8v1UUVEJ2K2OaN+pxNkb+4pjmDV/gcooogia1znc6oIo4/HJX4v0CiiMRbG6S0n+ZE5tY3LcM/RUopat7G6WnypCIh3p5byD/AOKiiRq3xhksG/3iT67FPeWPkILLcQCN+iiiNzwqUCJafpLdTQQEljAZ5gRY0AfmrUTPJvsUG+z654wPDeptfaHVNcyOScNdyc4A7Hl71FFnfCnu08WkJZmvinZUmS+MtabOigd/K/0K5LAG1XPUFFEy+Gec8tPcDxOFcyT+ahga1jSfU/kooqU4YIGiqAG/NJbis0B1C+W6iiiuTGYNDS0VZVsxImODtAu/JUooVQwog0F0YN+ijsSDwt7sUSVFEpBCMYB8VhnJ7ehCoYrKBZI/S7l4jsooiW4MnZZxqcwd7ILB6qxjuDmj2iXc0DY/ZUora11iCKYxt+vefXZQY2S4jTO7Tu552FNAsqKK73Wesv6I4jPkZNFpqMbAXyCzQ4hkhDgd37g+5RRavK4zIOTh8obqL2ncC+VKn4D7JbpAUUWe1ayKGLK3W1xHhAqnHnsf1U9nyv8AiH/qFRRXenrH/9k=\" alt=\"An Image\"> " +
                "<img src=\"/images/images.jpeg\" alt=\"My Image\">" ;
    }

    @GetMapping("/calc/add/{n1}/{n2}")
    @ResponseBody
    public String add(@PathVariable int n1, @PathVariable int n2) {
        int res = n1+n2;
        if(res%2==0) {
            return "Even";
        }
            return "Odd";

        //return "Addition: " + (n1 + n2);
    }

    @GetMapping("/calc/sub/{n1}/{n2}")
    @ResponseBody
    public String sub(@PathVariable int n1, @PathVariable int n2) {
        return "Subtraction: " + (n1 - n2);
    }

    @GetMapping("/calc/mul/{n1}/{n2}")
    @ResponseBody
    public String mul(@PathVariable int n1, @PathVariable int n2) {
        return "Multiplication: " + (n1 * n2);
    }

    @GetMapping("/calc/div/{n1}/{n2}")
    @ResponseBody
    public String div(@PathVariable double n1, @PathVariable double n2) {
        return "Division: " + (n1 / n2);
    }

    @GetMapping("/name/{name}")
    @ResponseBody
    public String check(@PathVariable String name) {
        String n = name.toLowerCase();
        if(n.equals("samyuktha")){
            return "It's my name.";
        }
        return "I don't know you";
    }

    @GetMapping("/climate/{n}")
    @ResponseBody
    public String add(@PathVariable int n) {
        if(n<0) {
            return "Shivering";
        }
        else if(n>=0 && n<=15){
            return "Chill";
        }
        else if(n>15 && n<=24){
            return "Happy";
        }
        else if(n>24 && n<=30){
            return "Towards hot";
        }
        else if(n>30 && n<=32){
            return "Hotter";
        }
        else{
            return "OMG";
        }
    }

    @GetMapping("/intro/{name}/{city}/{course}")
    @ResponseBody
    public String div(@PathVariable String name, @PathVariable String city, @PathVariable String course) {
        return "Hello, I'm " + name + ", from " + city + " welcome to " + course;
    }
    
    //a full calculation with a single API end point.
    @GetMapping("/calc/{n1}/{n2}")
    public String calc(@PathVariable int n1, @PathVariable int n2) {
        StringBuilder sb = new StringBuilder();
        sb.append("Add: ").append(n1+n2).append("\n");
        sb.append("Sub: ").append(n1-n2).append("\n");
        sb.append("Mul: ").append(n1*n2).append("\n");
        if(n2!=0){
            sb.append("Quo: ").append(n1/n2).append("\n");
            sb.append("Rem: ").append(n1%n2).append("\n");
        }
        else{
            sb.append("Quo Division by zero is not allowed\n");
            sb.append("Quo Division by zero is not allowed\n");
        }
        return "<pre>" + sb.toString() + "</pre>";
    }

}