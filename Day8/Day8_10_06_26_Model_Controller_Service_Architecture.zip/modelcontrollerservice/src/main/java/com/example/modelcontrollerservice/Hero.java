package com.example.modelcontrollerservice;
//Model Class
public class Hero {
    private String name;
    private String power;

    //Getters & Setters
    public String getName(){
        return name;
    }
    public void setName(String name){
        this.name = name;
    }
    public String getPower(){
        return power;
    }
    public void setPower(String power){
        this.power = power;
    }

}
