package com.example.modelcontrollerservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ModelcontrollerserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ModelcontrollerserviceApplication.class, args);
	}

}
