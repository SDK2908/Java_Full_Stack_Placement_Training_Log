package com.example.modelcontrollerservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ModelcontrollerserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
