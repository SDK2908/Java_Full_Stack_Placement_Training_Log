package com.example.repositorylayer;

import java.util.ArrayList;
import java.util.List;

//repository class
public class StudentRepository {
    private final List<Student>students = new ArrayList<>();
    public List<Student> findAll(){
        return students;
    }

    public void save(Student s){
        students.add(s);
    }
}
