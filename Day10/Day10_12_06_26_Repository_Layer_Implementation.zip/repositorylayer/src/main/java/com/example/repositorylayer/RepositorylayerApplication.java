package com.example.repositorylayer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RepositorylayerApplication {

	public static void main(String[] args) {
		SpringApplication.run(RepositorylayerApplication.class, args);
	}

}
