package com.example.h2db;

import org.springframework.data.jpa.repository.JpaRepository;

public interface StudentRepository extends JpaRepository<Student,Long> {}

//JpaRepository ---> it is a spring data JPA interface that already has all the common CRUD methods built in.
//extends JpaRepository ---> by extending JpaRepository, our StudentRepository automatically gets methods like:
//  save(Student s) --> insert/update a student
//  findAll()   --> get all students
//  findById(Long id)   --> get one student
//  deleteById(Long id)   --> delete a student
//We don't need to write SQL or implement these methods ourselves - Spring generates them at runtime.
//<Student,Long>  ---> The first type parameter (Student) tells JPA which entity this repository manages.
//It's tied to your Student table.
//the second type parameter (Long) tells JPA the type of the primary key(id).
//since your student entity has private Long id; you specify Long.
//public interface StudentRepository ---> it is an interface, not a class.
//you don't write any code inside -- SpringBoot automatically creates a working implementation at runtime.