package com.example.h2db;
//model class and this is called as entity class here.

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;

@Entity//this is to represent that this is connected to the database

public class Student {
    @Id     //
    @GeneratedValue     //
    private Long id;
    private String name;

    public Student(){}      //required by JPA (Hibernate uses it internally)

    public Student(String name){        //convenience constructor for quick object creation
        this.name = name;
    }
    public Long getId(){
        return id;
    }
    public String getName(){
        return name;
    }
}
