import logo from './logo.svg';
import './App.css';

function App() {
  return (
    <div>
      <h1>This is my first React App!</h1>
      <h2>My name is Samyu</h2>
    </div>
  );
}

export default App;
