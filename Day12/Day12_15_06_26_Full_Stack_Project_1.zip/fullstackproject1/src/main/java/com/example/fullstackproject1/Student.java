package com.example.fullstackproject1;

import jakarta.persistence.*;
import lombok.Data;

import java.util.List;

@Entity
@Table(name="students_table") //custom table name
@Data       //From Lombok. Lombok generates getters/setters, toString, equals, hashCode
public class Student {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "student_id")        //custom column name
    private Long std_id;
    @Column(name = "student_name", nullable = false, length = 100)
    private String std_name;
    @OneToOne(cascade = CascadeType.ALL)        //if there are changes in the student table then the profile table will also change
    @JoinColumn(name = "profile_id", referencedColumnName = "id")       //reference is from profile table whic is a foreign key. profile_id will be created in the student table. it is a reference one and is a primary key in the profile table.
    private Profile profile;
    private String std_department;
    @OneToMany(mappedBy = "student", cascade = CascadeType.ALL)
    private List<Course> courses;       //one student has many courses
}
