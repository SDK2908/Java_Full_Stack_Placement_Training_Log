package com.example.rdbmspostgresdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RdbmspostgresdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
