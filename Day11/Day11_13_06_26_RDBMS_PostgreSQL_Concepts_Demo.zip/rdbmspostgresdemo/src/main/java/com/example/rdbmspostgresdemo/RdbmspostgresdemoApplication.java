package com.example.rdbmspostgresdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RdbmspostgresdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(RdbmspostgresdemoApplication.class, args);
	}

}
