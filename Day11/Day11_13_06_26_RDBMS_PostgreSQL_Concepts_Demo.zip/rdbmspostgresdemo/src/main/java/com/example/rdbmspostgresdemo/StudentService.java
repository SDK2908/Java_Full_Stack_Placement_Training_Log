package com.example.rdbmspostgresdemo;

public class StudentService {
}
