package com.example.rdbmspostgresdemo;

import jakarta.persistence.*;

@Entity
public class Student {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long studentId;

    private String studentName;

    @OneToOne
    @JoinColumn(name = "course_id")
    private Course course;

    public Student() {}

    public Student(String studentName, Course course) {
        this.studentName = studentName;
        this.course = course;
    }

    public Long getStudentId() {
        return studentId;
    }

    public String getStudentName() {
        return studentName;
    }

    public Course getCourse() {
        return course;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public void setCourse(Course course) {
        this.course = course;
    }
}