package com.example.onetoonedemo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/students")
public class StudentController {
    @Autowired
    private StudentService service;

    @PostMapping
    public Student create(@RequestBody Student s) {
        return service.save(s);
    }

    @GetMapping
    public List<Student> all() {
        return service.findAll();
    }
}