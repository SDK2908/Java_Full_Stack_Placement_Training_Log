package com.example.postgresdemo;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

//entity class
@Entity
public class Name {
    @Id         //to make the id as a primary key in table
    @GeneratedValue(strategy = GenerationType.IDENTITY)     //this is for the auto generation of the id
    private Long id;
    private String name;
    public Name(){}
    public Name(String name){
        this.name = name;
    }
    public Long getId(){
        return id;
    }
    public String getName(){
        return name;
    }
    public void setName(String name){
        this.name = name;
    }
}
