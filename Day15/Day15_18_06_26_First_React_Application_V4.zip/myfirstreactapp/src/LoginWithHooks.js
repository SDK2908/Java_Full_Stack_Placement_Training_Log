import React from 'react'
import { useState, useEffect } from 'react'

const LoginWithHooks = () => {
    const [user, setUser] = useState("");
    const [pass, setPass] = useState("");
    const [resuser, setResuser] = useState("");
    const [respass, setRespass] = useState("");

    const usern = "Samyu";
    const passs = "123";

    const handleClick=()=>{
        setResuser(user);
        setRespass(pass);
        if(user === usern && pass===passs){
        alert("Login Done")
    }
    else{
        alert("Failed")
    }
    }


  return (
    <div>
        <label>Username:</label>
      <input id="u" type="text" value={user} onChange={(e) => setUser(e.target.value)}></input>
      <br/>
      <label>Password</label>
      <input id="p" type="password" value={pass} onChange={(e) => setPass(e.target.value)}></input>
      <br/>
      <button onClick={handleClick}>Login</button>
      <br>
      </br>
      <br>
      </br>
      <br>
      </br>
      <hr></hr>
      <label>Username Entered:</label>
      <p>{resuser}</p>
      <br></br>
      <label>Password Entered:</label>
      <p>{respass}</p>
    </div>
  )
}

export default LoginWithHooks
