import React from 'react'
//this file is an explanation for the callback functon
//first 0 will be shown and then it must be incremented when the plus button is clicked and then the new value must be shown. do this without react hooks.
const StopClock = () => {
let n = 0
    const plus = () => {
        n++
        document.getElementById("res").textContent=n;
    }

    const minus = () => {
        n--
        document.getElementById("res").textContent=n;
    }

  return (
    <div>
      <button onClick={plus}>+</button>
      <button onClick={minus}>-</button>
      <h1 id="res">{n}</h1>
    </div>
  )
}

export default StopClock
