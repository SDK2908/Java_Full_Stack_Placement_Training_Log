import React from 'react'
import { useState, useEffect } from 'react'

const EffectEg = () => {
const [message, setMessage] = useState("Loading...");

useEffect(()=>{
    const timer = setTimeout(()=>{
        setMessage("Hello, this is useEffect example!");
    }, 4000) 
    return() => clearTimeout(timer); //it tells React, whenever this effect needs to be cleaned up, call this function.
}, []) // ← Dependency array. The dependency array tells React when to run the effect again.


  return (
    <div style={{textAlign:'center'}}>
      <h1>{message}</h1>
    </div>
  )
}

export default EffectEg
