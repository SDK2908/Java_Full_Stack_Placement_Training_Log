import React from 'react'
import { useState } from 'react'
//this is an example for the useState hook
const CounterClock = () => {
    const [count,setCount] = useState(0);  //inside useState the number is where the counter must start. it can be any number.

    const handlePlus = () => {
        setCount(count+1);
    }
    const handleMinus = () => {
        setCount(count-1);
    }
    const handleReset = () => {
        setCount(0);
    }

  return (
    //we can add style to the div 
    <div style={{textAlign: 'center' }}>
      <button onClick={handlePlus}>+</button>
      <button onClick={handleMinus}>-</button>
      <button onClick={handleReset}>Reset</button>
      <h3 id="res">{count}</h3>
    </div>
  )
}

export default CounterClock
