import logo from './logo.svg';
import './App.css';
// import {App1} from './App1';
// import { Compute } from './Compute';
//import UseState2 from './UseState2';  
// import CounterClock from './CounterClock';
//import EffectEg from './EffectEg';
//import EffectDependencyEg1 from './EffectDependencyEg1';
// import { LoginValidation } from './LoginValidation';
// import LoginWithHooks from './LoginWithHooks';
//import OnChangeEventEg from './OnChangeEventEg';
// import { SignupValidation } from './SignupValidation';
import RoutingEg from './RoutingEg';

function App() {
  return (
    <div>
      {/* <h1>This is my first React App!</h1> */}
      {/* <h2>My name is Samyu</h2> */}
      {/* <Compute /> */}
      {/* <App1 /> */}
      {/* <UseState2 /> */}
      {/* <EffectEg /> */}
      {/* <CounterClock /> */}
      {/* <EffectDependencyEg1 /> */}
      {/* <LoginValidation /> */}
      {/* <LoginWithHooks /> */}
      {/* <OnChangeEventEg /> */}
      {/* <SignupValidation /> */}
      <RoutingEg />
    </div>
  );
}
 
export default App;
