import React from 'react'
import { useState, useEffect } from 'react'

const EffectDependencyEg1 = () => {
    const [count, setCount] = useState(0);

    //useEffect runs everytime the count value changes
    //we get an alert everytime we click the increase button, and when we click okay in the alert only then the count is incremented.
    useEffect(()=>{
        console.log("Count changed to:", count);
        alert("Count is now "+count);
    }, [count])

  return (
    <div>
        <h1>Count: {count}</h1>
      <button onClick={()=>setCount(count+1)}>Increase</button>
    </div>
  )
}

export default EffectDependencyEg1
