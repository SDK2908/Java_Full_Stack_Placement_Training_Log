import React from 'react'

const AboutComponent = () => {
  return (
    <div>
      <h1>This is the About page</h1>
      <p>This about page component is rendered in the RoutingEg file.</p>
    </div>
  )
}

export default AboutComponent
