import React from 'react'
import { useState } from 'react'

const UseState2 = () => {
    const [count,setCount] = useState(0)
  return (
    <div style={{textAlign: 'center' }}>
      <button onClick={()=>setCount(count+1)}>+</button>
      <button onClick={()=>setCount(count-1)}>-</button>
      <h3 id="res">{count}</h3>
    </div>
  );
}

export default UseState2
