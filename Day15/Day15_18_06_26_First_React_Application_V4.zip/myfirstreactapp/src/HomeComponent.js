import React from 'react'
//example for the routing but with components ouside the route file
const HomeComponent = () => {
  return (
    <div>
      <h1>This is the Home page</h1>
      <p>This home page component is rendered in the RoutingEg file.</p>
    </div>
  )
}

export default HomeComponent
