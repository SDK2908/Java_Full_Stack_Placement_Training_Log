// import React from 'react'

// const OnChangeEventEg = () => {
//     const handleChange=(e)=>{
//         document.getElementById("log").textContent = e.target.value;
//     }
//   return (
//     <div>
//      <label>Type any text to see it as you type on the screen using OnChange Event:</label>
//      <br></br>
//       <input 
//       type="text"
//       onChange={handleChange}>
//       </input>
//       <p id="log"></p>
//     </div>
//   )
// }

// export default OnChangeEventEg


//this is using the useState
import React from 'react'
import { useState} from 'react'

const OnChangeEventEg = () => {
    const [text, setText] = useState("");
  return (
    <div>
        <input 
       type="text"
       onChange={(e) => setText(e.target.value)}>
       </input>
      <p>{text}</p>
    </div>
  )
}

export default OnChangeEventEg
