import React from 'react'

export const LoginValidation = () => {
    const username = "Samyu";
    const password = "123";


    const handleClick=() =>{
            const usern = document.getElementById("userid").value;
            const userp = document.getElementById("userpass").value;
        if(username === usern && password === userp){
            alert("Login Sucessfull!");
        }
        else if(username!==usern && password!==userp){
            alert("Check your username and password again!")
        }
        else if(password!==userp){
            alert("Check your password again!")
        }
        else{
            alert("Check your username again!")
        }
    }

  return (
    <div>
      <label>Enter Name:</label>
      <input type='text' id='userid'></input>
      <br/>
      <label>Enter Password:</label>
      <input type='password' id='userpass'></input>
      <br/>
      <button onClick={handleClick}>Login</button>
    </div>
  )
}

