//name,phone no,email.id,username, password, confirm password, dob
//everyfield should be entered except phone no.
//password must contain min 8 characters, max 15, and one number, one special char is mandatory
//add placeholder no need labels.
import React from 'react'
import { useState } from 'react'

export const SignupValidation = () => {
    const [name, setName] = useState("");
    const [email, setEmail] = useState("");
    const [phone, setPhone] = useState("");
    const [dob, setDob] = useState("");
    const [username, setUser] = useState("");
    const [password, setPass] = useState("");
    const [confirmpass, setCpass] = useState("");

    const handleSubmit=()=>{
        if (
            name === "" ||
            email === "" ||
            dob === "" ||
            username === "" ||
            password === "" ||
            confirmpass === ""
        ) {
            alert("All fields are required!");
        }
        else if (
            password.length < 8 ||
            password.length > 15
        ) {
            alert("Password should contain 8 to 15 characters");
        }
        else if (
            !/^(?=.*[0-9])(?=.*[!@#$%^&*])[A-Za-z0-9!@#$%^&*]+$/.test(password)
        ) {
            alert(
                "Password must contain at least one number and one special character"
            );
        }
        else if (password !== confirmpass) {
            alert("Passwords do not match");
            }
        else {
            alert("Signup Successful");
        }
    }

  return (
    <div align="center">
        <br></br>
        <h1>SignUp Page</h1>
        <br></br>
        <br></br>
        <br></br>
      <input 
      type='text' 
      id="name" 
      placeholder='Name' 
      onChange={(e) => setName(e.target.value)}>
      </input>
      <br></br>
      <br></br>
      <input 
      type="email" 
      id="email" 
      placeholder='Email Id' 
      onChange={(e) => setEmail(e.target.value)}>
      </input>
        <br></br>
        <br></br>
      <input 
      type="text" 
      id="phone" 
      placeholder='Phone Number' 
      onChange={(e) => setPhone(e.target.value)}>
      </input>
<br></br>
<br></br>
      <input 
      type="date" 
      id="dob" 
      placeholder='DOB' 
      onChange={(e) => setDob(e.target.value)}>
      </input>
<br></br>
<br></br>
      <input 
      type='text' 
      id="username" 
      placeholder='Username' 
      onChange={(e) => setUser(e.target.value)}>
      </input>
<br></br>
<br></br>
      <input 
      type="password" 
      id="password" 
      placeholder='Password' 
      onChange={(e) => setPass(e.target.value)}>
      </input>
<br></br>
<br></br>
      <input 
      type="password" 
      id="confirmpass" 
      placeholder='Confirm Password' 
      onChange={(e) => setCpass(e.target.value)}>
      </input>
<br></br>
<br></br>
      <button onClick={handleSubmit}>Submit</button>
    </div>
  )
}
