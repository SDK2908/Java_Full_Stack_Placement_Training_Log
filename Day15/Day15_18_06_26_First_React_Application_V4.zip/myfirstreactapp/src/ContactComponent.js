import React from 'react'

const ContactComponent = () => {
  return (
    <div>
      <h1>This is the Contact page</h1>
      <p>This home contact component is rendered in the RoutingEg file.</p>
    </div>
  )
}

export default ContactComponent
