import React from 'react'
import { BrowserRouter, Routes, Route, Link } from 'react-router-dom'
import HomeComponent from './HomeComponent'
import ContactComponent from './ContactComponent'
import AboutComponent from './AboutComponent'
import LoginWithHooks from './LoginWithHooks'
import {SignupValidation} from './SignupValidation'

const RoutingEg = () => {
  return (
    <BrowserRouter>
    <div align="center">
      <h1>Routing Demo</h1>
    <nav>
        <Link to="/">Home</Link> | {" "}
        <Link to="/about">About</Link> | {" "}
        <Link to="/contact">Contact</Link> | {" "}
        <Link to="/login">Login</Link> | {" "}
        <Link to="/signup">Signup</Link>
    </nav>
    <Routes>
        <Route path="/" element={<HomeComponent />}></Route>
        <Route path="/about" element={<AboutComponent />}></Route>
        <Route path="/contact" element={<ContactComponent />}></Route>
        <Route path="/login" element={<LoginWithHooks />}></Route>
        <Route path="/signup" element={<SignupValidation />}></Route>
    </Routes>
     </div>
    </BrowserRouter>
  )
}

export default RoutingEg
