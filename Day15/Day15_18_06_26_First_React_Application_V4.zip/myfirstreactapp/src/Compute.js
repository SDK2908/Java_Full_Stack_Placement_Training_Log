import React from 'react'
import imagess from './images.jpeg'
import imagessss from './image1.jpg'

export const Compute = () => {
    const n = 10;
    const handleClick=()=>
    {
      document.getElementById("res").textContent = "First Button Clicked!";
    }

    const handleClick1=()=>
    {
      const msg = document.getElementById("res");
      msg.textContent = "Second Button Clicked!";
      msg.style.color = "red";
    }
    const handleonClick=()=>
    {
      const msg = document.getElementById("ress").textContent = "Text Clicked!";
    }
    const handleonnClick=()=>{
      const msg = document.getElementById("resss").src = imagessss;
    }

  return (
    <div>
      <h1>Event Handling: {n}</h1>
      <button onClick={handleClick}>Compute</button>
      <button onClick={handleClick1}>Another Button</button>
      <h2 id="res">This is gonna be replaced when the button is clicked</h2>
      <h2 onClick={handleonClick}  id="ress">This is gonna be replaced when the text is clicked</h2>
      <img id="resss" onClick={handleonnClick} src={imagess} alt="Computer" />
    </div>
  )
}

