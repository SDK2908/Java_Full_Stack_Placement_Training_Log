import logo from './logo.svg';
import './App.css';
import {App1} from './App1';

function App() {
  return (
    <div>
      <h1>This is my first React App!</h1>
      <h2>My name is Samyu</h2>
      <App1 />
    </div>
  );
}
 
export default App;
